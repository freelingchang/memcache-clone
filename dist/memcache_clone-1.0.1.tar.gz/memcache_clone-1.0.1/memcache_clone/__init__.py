from .memcache_clone import memcache
